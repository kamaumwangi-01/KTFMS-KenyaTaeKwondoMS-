<div class="container-fluid">
<div id="footer" style="background:black">
		
		KENYA TAEKWONDO FEDERATION (KTF)<br>
          Headquarters: Kenya national Sports Council Offices- Msa Road<br>

    P. O Box 61002-00200, Nairobi.<br>
    Tel: 074498539<br>
    Email: info@kenyataekwondo.co.ke<br>
    NAIROBI<br>
    Affiliated to KNSC, NOCK, AFTU, WTF<br>
    &copy; Kenya Taekwondo Federation 2019. All rights reserved
    <hr>
    <h6 style="float:right"><b ><span class="glyphicon glyphicon-asterisk fa-spin"></span> Powered By:</b> <i>Techfy Technologies (+254726159307)</i></h6>
		</div>
	
</div>