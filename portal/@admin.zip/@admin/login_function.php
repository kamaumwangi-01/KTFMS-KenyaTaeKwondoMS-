 <?php
  $pass='';
  $email='';
  $dbnum='';
 if (empty($_POST)===false) {

  $email=$_POST['email'];
  $pass=$_POST['password'];
     
  $sqls="SELECT email,password FROM admin WHERE email='$email'";
          $results=mysqli_query($con,$sqls) or die(mysql_error());
          while($rows=mysqli_fetch_array($results))
              {
               $dbpassword=$rows['password'];
               $dbemail=$rows['email'];
               
              }
              
        if ($pass===$dbpassword)
        {
          
          $_SESSION['myemail']=$dbemail;
          $_SESSION['mypassword']=$dbpassword;
            header("location: @admin_@panel_@manage.php");

                             
        }
        else{
          ?>
      <script>
      alert("Wrong number or password");
      </script>
      <?php
        
        }
      
 }

             // echo $dbnum;
?>